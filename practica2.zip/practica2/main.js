// Primer Ejercicio
let array = [10,20,30,40,50] 
 let max = array [0]

 for (let i = 0; i < array.length; i++) {
    if (array[i] > max) {
        max = array[i];
    }}; console.log (max);

// Cuarto Ejercicio
 let listaDeNumeros = prompt ("Digite los tres números, divididos por una coma")
listaDeNumeros = listaDeNumeros.split(",");
console.log(listaDeNumeros)
function encontrarDuplicados(datos) {
    let duplicados = [];
    for (let i = 0; i < datos.length; ++i) {
        console.log(datos.slice(i + 1));
        if (i + 1 < datos.length && datos.slice(i + 1).indexOf(datos[i]) != -1 && duplicados.indexOf(datos[i]) == -1) {
            duplicados.push(datos[i]);
        }
    }
     return duplicados;}
let numeros = listaDeNumeros;
console.log(numeros);
console.log(numeros.length);
console.log();
let resultado = encontrarDuplicados(numeros);
console.log(resultado)